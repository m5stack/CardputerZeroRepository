# BeaconHound

**Pocket Wireless Spectrum HUD, 6E Site Survey Doctor & Counter-Surveillance Radar for M5Stack CardputerZero**

`BeaconHound` (`beaconhound`) is a native, keyboard-first wireless diagnostics and passive spectrum mapping instrument built specifically for the **M5Stack CardputerZero** (`320x170` LCD, 46-key matrix keyboard, `512 MB RAM`).

## Edition Matrix (Open-Core)

| Capability | Community (Free / Built-in Radio) | Pro Suite (`Cap 5G-Wardrive` Unlocked) |
| :--- | :--- | :--- |
| **Radio Spectrum** | Onboard `wlan0` 2.4 GHz (Ch 1–14) | Tri-Band **2.4 / 5 / 6 GHz Wi-Fi 6E** (`wlan1`) + `hci0` BLE |
| **6 GHz Discovery** | Guide preview | **RNR (Element ID 201) `<35ms` Sniper Hopping + 15 PSC Sweep** |
| **Positioning & Timing** | Manual keyboard waypoint | **LNA+SAW 6-Constellation GNSS + `1PPS` Sub-ms Timestamp** |
| **Enterprise Site Survey** | Live 2.4 GHz RSSI table | **6E RNR/WPA3/PMF Health Audit + White-Label HTML Report** |
| **Privacy & Evidence** | Nearby BLE counter | **Chasing-Your-Tail Correlation + 8MP Geo-Watermarked Capture** |
| **Companion & Watchdog** | Standalone `320x170` HUD | **On-Demand `wlan0` Web Deck + `PYG13_HAT_EN` Auto-Recovery** |

## Keyboard Shortcuts (`320x170` Tactical HUD)

- `[1]` **6E Sniper HUD** — Tri-band packet velocity bars, unique AP counters, GNSS `CN0` & `1PPS` lock LED
- `[2]` **Site Survey Doctor** — RNR neighbor chain check, WPA3/PMF validation, room spot-check tagging
- `[3]` **Tail & Privacy Radar** — Spatio-temporal follower correlation & infrastructure OUI alerts
- `[4]` **System & Export** — `[W]` Companion Web Deck QR, `[K]` Native Kismet handover, `[D]` Kernel Doctor
- `[C]` **8MP Evidence** — Capture rear `IMX219` frame stamped with RF fingerprint, GNSS & `1PPS` UTC
- `[S]` **Sleep Cruise** — Turn off LCD backlight for low-power passive logging with audio cues

## Building & Verification

```bash
bash .gemini/verify.sh
```

## License

Community UI and IPC protocol headers in this repository are licensed under the MIT License (`PINGEQUA_Lab`).
